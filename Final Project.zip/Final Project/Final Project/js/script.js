$(document).ready(function () {
    $(".blogs").owlCarousel({
        items: 6,
        loop: true,
        margin: 15,
        nav: true,
        dots: false,
        navText: [
            '<i class="bi bi-chevron-left"></i>',
            '<i class="bi bi-chevron-right"></i>'
        ],
        responsive: {
            0: { items: 1 },
            576: { items: 1 },
            768: { items: 2 },
            992: { items: 3 }
        }
    });
});

$(document).ready(function () {
    $(".flash-products").owlCarousel({

        loop: true,
        margin: 15,
        nav: true,
        dots: false,
        navText: [
            '<i class="bi bi-chevron-left"></i>',
            '<i class="bi bi-chevron-right"></i>'
        ],
        responsive: {
            0: { items: 1 },
            576: { items: 2 },
            768: { items: 3 },
            992: { items: 5 }
        }
    });
});

$(document).ready(function () {
    $(".first-products").owlCarousel({

        loop: true,
        margin: 15,
        nav: false,
        dots: false,
        autoplay: false,
        autoplayTimeout: 5000,
        autoplaySpeed: 1000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1,
                autoplay: true
            },
            576: {
                items: 2,
                autoplay: true
            },
            768: {
                items: 4,
                autoplay: true
            },
            992: { items: 8 }
        }
    });
});



  document.addEventListener("DOMContentLoaded", function () {
    const offcanvasData = document.querySelector(".offcanvasData");

    offcanvasData.innerHTML = `
      <a href="tel:+9239427879"
        class="d-flex align-items-center secondaryColor justify-content-around col-lg-12 py-2">
        <i class="bi bi-telephone h3 m-0 me-2"></i>
        <div>
          <p class="m-0">Contact us 24/7</p>
          <span class="fw-bold">(+92) 3942 7879</span>
        </div>
      </a>
    `;

  
    offcanvasData.classList.add("d-none");

    const listBtn = document.querySelector(".list-button");

    listBtn.addEventListener("click", function () {
      offcanvasData.classList.toggle("d-none");
      offcanvasData.classList.toggle("d-block");
    });
  });
  